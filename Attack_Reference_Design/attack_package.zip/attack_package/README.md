# Attack Package
### Attacker Decoder
 - *image*: attacker.bin
 - *Decoder ID*: 0xdeadbeef

### Subscriptions
 - *sub_1.bin*: Subsscription to channel 1 for attacker decoder.
 - *sub_2.bin*: Subsscription to channel 2 for attacker decoder. 
 - *sub_3.bin*: Subsscription to channel 3 for unknown decoder.

### Frame Recordings
 - *frame_playback.json*: JSON file of a list of recorded frames from channel 1.